
function m() 
{
  document.getElementById("demo")
  .style.display = "block";
}

function p()
{
  document.getElementById("demo")
  .style.display = "none";
}function b()
{
  location. assign(' https://www.apple.com/in/shop/buy-iphone/iphone-12')
}function login()
{
  location.assign('Login.html')
}